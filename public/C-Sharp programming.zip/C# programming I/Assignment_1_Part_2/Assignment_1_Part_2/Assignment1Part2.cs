﻿/* W. Bowers (c) 2016, All Rights Reserved.
Additional modifications by H. Truong, 2016
*/

using System;

    class Assignment1Part2
    {
        static void Main(string[] args)
        {
            BowersHeading.getHeading("Assignment 1, Part 2");
            Console.WriteLine("  The stars at night\n  " 
                              + "Are big and bright\n\n  " 
                              + "(Clap)\n  (Clap)\n  (Clap)\n  (Clap)\n\n  "
                              + "Deep in the heart of Texas!");
            BowersHeading.getClosing();
        }
    }

