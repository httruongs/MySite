/* Name : Huong Truong
 * Class : CSCI 2240-003
 * Program # : 3
 * Due Date : Oct 24 2016
 *
 * Honor Pledge: On my honor as a student of the University
 * of Nebraska at Omaha, I have neither given nor received
 * unauthorized help on this homework assignment.
 *
 * NAME: Huong Truong
 * EMAIL: httruong@unomaha.edu
 * NUID: 52233854
 * Colleagues: None
 */

/* Fuction Name: main
 * Parameters: argc, argv for command line arguments
 * Return: 0 for successful execution
 * Description: This program will compile the data passed in and stored in memory. Then it executes the instructions in memory.
 */


#include <stdio.h>
#include <string.h>
#include "vc_memory.h"
#include "vc_execution.h"
#include "vc_compilation.h"

int main()
{
    Memory memory;
    memset(&memory, 0, sizeof(memory));
    compile(&memory);
    /* If memory->instrucionRegister == 1 a compilation error occured */
    if(!memory.instructionRegister) {
        execute(&memory);
    }
    return 0;
}
